<?php
defined('MOODLE_INTERNAL') || die();

// Keine eigenen Capabilities nötig, wir prüfen auf moodle/cohort:assign.
$capabilities = [];