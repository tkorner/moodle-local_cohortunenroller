<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_cohortunenroller';
$plugin->version   = 2025090102;   // YYYYMMDDXX
$plugin->requires  = 2024052000;   // Moodle 4.5
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '0.3.1';