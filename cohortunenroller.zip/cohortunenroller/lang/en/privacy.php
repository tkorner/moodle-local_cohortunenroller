<?php
$string['privacy:metadata'] = 'This plugin does not store any personal data.';